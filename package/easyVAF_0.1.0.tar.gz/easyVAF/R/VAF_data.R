#' @docType data
#'
#' @usage data(dat)
#'
#'
#' @keywords datasets
#'
#' @examples
#' data(dat)
#' names(VAF)
#' head(VAF)
