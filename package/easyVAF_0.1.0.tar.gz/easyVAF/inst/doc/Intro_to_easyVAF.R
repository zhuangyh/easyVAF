## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----flowchart, fig.cap = "SmCCNet workflow overview. .", echo = FALSE, eval=FALSE----
#  knitr::include_graphics("easyVAFWorkflow.pdf")

## ---- echo = FALSE, results = "hide", warning = FALSE, eval = TRUE------------
suppressPackageStartupMessages({
    library(dplyr)
    library(tibble)
    library(aod)
    library(ggplot2)
    library(lme4)
})

## ----example data, results="asis"---------------------------------------------
library(easyVAF)
library(knitr)
data(VAF)
names(VAF)
print(kable(head(VAF), row.names=F,
            caption="VAF data example"))


## ----QC, warning = FALSE, results="asis"--------------------------------------
rslt <- QCchecking(data=VAF, method="lm")
rslt

## ----Tarone, warning = FALSE, results="asis"----------------------------------
Tarone.test(sum(VAF$dp),sum(VAF$vc))

## ----mainCom, results="asis", warning = FALSE---------------------------------
library(easyVAF)
#4 groups
groups <- unique(VAF$group)[c(1:4)]
rslt <- VAFmain(data=VAF, groups=groups)
rslt$P.value <- as.numeric(rslt$P.value)
names(rslt)
toploci <- head(rslt[order(as.numeric(rslt$P.value)), c("ID",
"P.value",          
"Overdispersion",   "p.adjust",       
"sig.diff.fdr")], n=10)

print(kable(toploci, row.names=F,
            caption="Top 10 significantly different loci, multiple group comparison",
            digits=3))
            

groups <- unique(VAF$group)[c(1:2)]
rslt <- VAFmain(data=VAF, groups=groups)
rslt$P.value <- as.numeric(rslt$P.value)
names(rslt)
toploci <- head(rslt[order(as.numeric(rslt$P.value)), c("ID",     "Effect.size",  "95% CI",   
                "p.adjust", "sig.diff.fdr", "Change.direction")], n=10)

print(kable(toploci, row.names=F,
            caption="Top 10 significantly different loci, two groups",
            digits=3))
            

